import { LightningElement,api } from 'lwc';

export default class PremiumSavingsAppEmail extends LightningElement {
    @api emailaddress
    
    handleemailvalue =(event)=>{
        this.emailaddress = event.target.value
    }

    @api emaildatatransfer=()=>{
        this.dispatchEvent(new CustomEvent('emaildata',{
            detail: {emailid: this.emailaddress}
        }  ))
    }

    @api validationoncontinue(){
        let valid= [...this.template.querySelectorAll('.requiredfield')].reduce((validsofar, field) => {
            field.reportValidity()
            return validsofar && field.reportValidity()
        }, true)
            return valid
    }
}