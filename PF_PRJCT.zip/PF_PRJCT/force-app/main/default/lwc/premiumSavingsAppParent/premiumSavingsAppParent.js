import { LightningElement } from 'lwc';
import userInformationinsert from '@salesforce/apex/userinformationcontroller.userInformationinsert';

export default class PremiumSavingsAppParent extends LightningElement {
    myHeader='Welcome to your Bank! Tell us about yourself.'
    mySubheader='Personal Information'
    editdispplay=false
    userpersonaldata ={}
    

    handleContinue(event){
        
        let allvalid = [...this.template.querySelectorAll('.requiredcheck')].reduce((allvalidsofar, field) => {
            field.validationoncontinue()
            return allvalidsofar && field.validationoncontinue()
                }, true)

        let buttonname= event.target.name

        if(!(buttonname=='confirm')){
            var consentvalid = this.template.querySelector('c-premium-savings-app-consent').validationoncontinue();
        }else{
            var consentvalid= true
        }
 
        if (allvalid && consentvalid){
            this.template.querySelector('c-premium-savings-app-name').namedatatransfer();
            this.template.querySelector('c-premium-savings-app-email').emaildatatransfer();
            this.template.querySelector('c-premium-savings-app-phone').phonedatatransfer();
            this.editdispplay = !this.editdispplay;
        }
    }

    namefetch(event){
        let formFirstname = event.detail.firstname
        let formLastname  = event.detail.lastname
        let formMiddleInitial = event.detail.middlename
        this.userpersonaldata ={...this.userpersonaldata,"firstname": formFirstname,"lastname": formLastname,"middleinitial": formMiddleInitial}
    }

    emailfetch(event){
        let formEmailid = event.detail.emailid
        this.userpersonaldata ={...this.userpersonaldata,"emailaddress": formEmailid}
    }
    
    phonefetch(event){
        let formPn = event.detail.phonenumber
        let formHpn = event.detail.homenumber
        let formWpn = event.detail.worknumber
        this.userpersonaldata ={...this.userpersonaldata,"phonenumber": formPn,"homenumber": formHpn,"worknumber": formWpn}
        
    }

    handleConfirm(event){
        this.handleContinue(event);
        let userdata = JSON.stringify(this.userpersonaldata);
        console.log(userdata)
        userInformationinsert({userdataip:userdata}).then(result=>{console.log('Successfully Inserted')}).catch(error=>{console.error(error)})
    }
    handleBack(){
        this.editdispplay = !this.editdispplay    
    }


}