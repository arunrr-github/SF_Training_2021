import { LightningElement, api} from 'lwc';

export default class PremiumSavingsAppName extends LightningElement {
    @api firstname
    @api lastname
    @api mi=''
    handlenamevalue =(event)=>{
        let classnname = event.target.name
        if (classnname=='fname') {
            this.firstname = event.target.value
        }else if (classnname=='lname') {
            this.lastname = event.target.value
        }else{
            this.mi = event.target.value
        }
    }

    @api namedatatransfer(){
        this.dispatchEvent(new CustomEvent('namedata',{
            detail: {  firstname: this.firstname,
                        lastname: this.lastname,
                        middlename: this.mi
                    }
        }                                  ))
    }

    @api validationoncontinue(){
        let valid= [...this.template.querySelectorAll('.requiredfield')].reduce((validsofar, field) => {
            field.reportValidity()
            return validsofar && field.reportValidity()
        }, true)
            return valid
    }
}
