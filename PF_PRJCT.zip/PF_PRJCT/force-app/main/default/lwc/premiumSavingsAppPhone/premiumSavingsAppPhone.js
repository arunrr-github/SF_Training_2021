import { LightningElement,api } from 'lwc';

export default class PremiumSavingsAppPhone extends LightningElement {
    @api mobilenumber=''
    @api homenumber=''
    @api worknumber=''

    handlephonevalue =(event)=>{
        let classpname = event.target.name
        if(classpname=='mobile'){
            this.mobilenumber =  event.target.value    
        }else if(classpname=='home'){
            this.homenumber = event.target.value
        }else{
            this.worknumber = event.target.value
        } 
    }

    @api phonedatatransfer(){   
        this.dispatchEvent(new CustomEvent('phonedata',{
            detail: {  phonenumber: this.mobilenumber,
                       homenumber: this.homenumber,
                       worknumber: this.worknumber
                    }
        }                                   ))
    }

    @api validationoncontinue(){
        let valid= [...this.template.querySelectorAll('.requiredfield')].reduce((validsofar, field) => {
            field.reportValidity()
            return validsofar && field.reportValidity()
        }, true)
            return valid
    }
}