import { LightningElement,api } from 'lwc';

export default class PremiumSavingsAppFormHeader extends LightningElement {

    @api header
    @api subheader

}