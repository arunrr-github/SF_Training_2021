import { LightningElement,api } from 'lwc';

export default class PremiumSavingsAppConsent extends LightningElement {
    enablemodal=false
    psaccheckbox=false
    handleconsentclick(){
        this.enablemodal= !this.enablemodal
    }
    handlecheckbox(){
        this.psaccheckbox=!this.psaccheckbox
        this.validationoncontinue(); 
    }
    @api validationoncontinue(){
        let allvalid= [...this.template.querySelectorAll('.requiredfield')].reduce((validsofar, field) => {
            field.reportValidity()
            return validsofar && field.reportValidity()
        }, true)
            return allvalid
    }
    
}